<!--Hero Area-->
<section class="hero-area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-7 col-md-12 col-sm-12 col-xs-12">
                        <audio id="urario-radio" controls="" autoplay="autoplay"><source src="http://173.82.168.159:8036/index.html" type="audio/mp3">Your browser does not support the audio element.</audio>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-7 col-md-12 col-sm-12 col-xs-12">
                        <div class="hero-content">
                            <h2>Bienvenidos a<br>Global Music Online</h2>
                            <p> Desde que entras en GMO se siente un espiritu alegre y familiar. Disfruta la mejor musica junto a tu familia online.
                            </p>
                            <a href="<?=base_url('radio-programs')?>" class="bttn-mid btn-fill">Radio GMO</a>
                        </div>
                    </div>
                </div>
                


            </div>
        </section><!--/Hero Area-->

        <!--Radio Programs
        <section class="radio-programs section-padding-2">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-7 col-md-12 col-sm-12 col-xs-12 centered wow fadeInUp" data-wow-delay="0.3s">
                        <div class="section-title cl-black">
                            <h2>Nuestra Programación</h2>
                            <p>His having within saw become ask passed misery giving. Recommend questions get too fulfilled. He fact in we case miss sake. </p>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12 wow fadeInUp" data-wow-delay="0.4s">
                        <div class="single-radio-program">
                            <img src="assets/images/single-radio-program-1.jpg" alt="">
                            <h3><a href="#">Sunday Night Special</a></h3>
                            <div class="program-meta">
                                <span>10.00 PM</span>
                                <span>Sunday to Friday</span>
                                <span><a href="rj-profile.html">RJ Nixon</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12 wow fadeInUp" data-wow-delay="0.5s">
                        <div class="single-radio-program">
                            <img src="assets/images/single-radio-program-2.jpg" alt="">
                            <h3><a href="#">Sunday Night Special</a></h3>
                            <div class="program-meta">
                                <span>10.00 PM</span>
                                <span>Sunday to Friday</span>
                                <span><a href="rj-profile.html">RJ Nixon</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12 wow fadeInUp" data-wow-delay="0.6s">
                        <div class="single-radio-program">
                            <img src="assets/images/single-radio-program-3.jpg" alt="">
                            <h3><a href="#">Sunday Night Special</a></h3>
                            <div class="program-meta">
                                <span>10.00 PM</span>
                                <span>Sunday to Friday</span>
                                <span><a href="rj-profile.html">RJ Nixon</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12 wow fadeInUp" data-wow-delay="0.7s">
                        <div class="single-radio-program">
                            <img src="assets/images/single-radio-program-4.jpg" alt="">
                            <h3><a href="#">Sunday Night Special</a></h3>
                            <div class="program-meta">
                                <span>10.00 PM</span>
                                <span>Sunday to Friday</span>
                                <span><a href="rj-profile.html">RJ Nixon</a></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section><!--/Radio Programs-->

        <!--Radio Jockey
        <section class="radio-jockey-area section-padding-2 gray-bg">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-7 col-md-12 col-sm-12 col-xs-12 centered wow fadeInUp" data-wow-delay="0.3s">
                        <div class="section-title cl-black">
                            <h2>Radio Jockey</h2>
                            <p>His having within saw become ask passed misery giving. Recommend questions get too fulfilled. He fact in we case miss sake.</p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 wow fadeInLeft" data-wow-delay="0.4s">
                        <div class="single-radio-jockey">
                            <img src="assets/images/rj-1.jpg" alt="">
                            <div class="radio-jockey-des">
                                <h4>RJ Eleanor</h4>
                                <p>Party Mood</p>
                                <div class="rj-social">
                                    <a href="#"><i class="fa fa-facebook"></i></a>
                                    <a href="#"><i class="fa fa-twitter"></i></a>
                                    <a href="#"><i class="fa fa-instagram"></i></a>
                                    <a href="#"><i class="fa fa-linkedin"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 wow fadeInUp" data-wow-delay="0.4s">
                        <div class="single-radio-jockey">
                            <img src="assets/images/rj-2.jpg" alt="">
                            <div class="radio-jockey-des">
                                <h4>RJ Eleanor</h4>
                                <p>Party Mood</p>
                                <div class="rj-social">
                                    <a href="#"><i class="fa fa-facebook"></i></a>
                                    <a href="#"><i class="fa fa-twitter"></i></a>
                                    <a href="#"><i class="fa fa-instagram"></i></a>
                                    <a href="#"><i class="fa fa-linkedin"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 wow fadeInRight" data-wow-delay="0.4s">
                        <div class="single-radio-jockey">
                            <img src="assets/images/rj-3.jpg" alt="">
                            <div class="radio-jockey-des">
                                <h4>RJ Eleanor</h4>
                                <p>Party Mood</p>
                                <div class="rj-social">
                                    <a href="#"><i class="fa fa-facebook"></i></a>
                                    <a href="#"><i class="fa fa-twitter"></i></a>
                                    <a href="#"><i class="fa fa-instagram"></i></a>
                                    <a href="#"><i class="fa fa-linkedin"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section><!--/Radio Jockey-->

        <!--Daily Program Schedule-->
        <section class="program-schedule section-padding dark-overlay" style="background: url('assets/images/program-bg.jpg') fixed;">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-7 col-md-12 col-sm-12 col-xs-12 centered wow fadeInUp" data-wow-delay="0.3s">
                        <div class="section-title cl-white">
                            <h2>Horario diario del programa</h2>
                            <p>Cada semana tenemos la mejor programación, pensando en cada uno de los miembros de esta gran familia de GMO.</p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 mb-30 wow fadeInLeft" data-wow-delay="0.4s">
                        <div class="nav flex-column nav-pills program-schedule-navs" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                            <a class="nav-link active" id="v-pills-monday-tab" data-toggle="pill" href="#v-pills-monday" role="tab" aria-controls="v-pills-monday" aria-selected="true">Lunes</a>

                            <a class="nav-link" id="v-pills-tuesday-tab" data-toggle="pill" href="#v-pills-tuesday" role="tab" aria-controls="v-pills-tuesday" aria-selected="false">Martes</a>

                            <a class="nav-link" id="v-pills-wednesday-tab" data-toggle="pill" href="#v-pills-wednesday" role="tab" aria-controls="v-pills-wednesday" aria-selected="false">Miercoles</a>

                            <a class="nav-link" id="v-pills-thursday-tab" data-toggle="pill" href="#v-pills-thursday" role="tab" aria-controls="v-pills-thursday" aria-selected="false">Jueves</a>

                            <a class="nav-link" id="v-pills-friday-tab" data-toggle="pill" href="#v-pills-friday" role="tab" aria-controls="v-pills-friday" aria-selected="false">Viernes</a>

                            <a class="nav-link" id="v-pills-saturday-tab" data-toggle="pill" href="#v-pills-saturday" role="tab" aria-controls="v-pills-saturday" aria-selected="false">Sabado</a>
                        </div>
                    </div>
                    <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12 wow fadeInRight" data-wow-delay="0.4s">
                        <div class="tab-content program-schedule-content" id="v-pills-tabContent">
                            <div class="tab-pane fade show active table-responsive table-responsive-sm table-responsive-xs" id="v-pills-monday" role="tabpanel" aria-labelledby="v-pills-monday-tab">
                                <table class="table table-borderless">
                                  <thead>
                                    <tr>
                                      <th scope="col">Horario</th>
                                      <th scope="col">Espacio Radial</th>
                                      <th scope="col">Conductor</th>
                                      <th scope="col">Twitter</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td>06.00am - 8:00am</td>
                                      <td>Good Morning Network</td>
                                      <td>Rj Rockey</td>
                                      <td>@rrockey</td>
                                    </tr>
                                    <tr>
                                      <td>08.00am - 10:30am</td>
                                      <td>Musty with ron</td>
                                      <td>Rj Ronne</td>
                                      <td>@ronne</td>
                                    </tr>
                                    <tr>
                                      <td>10.00am - 1:00pm</td>
                                      <td>Gaan Bazz</td>
                                      <td>Rj Pinkey</td>
                                      <td>@pinkey</td>
                                    </tr>
                                    <tr>
                                      <td>1.30pm - 3:30pm</td>
                                      <td>Lounge Adda</td>
                                      <td>Rj Nusra</td>
                                      <td>@nusra</td>
                                    </tr>
                                    <tr>
                                      <td>3.30pm - 5:00pm</td>
                                      <td>Lounge Adda</td>
                                      <td>Rj Nusra</td>
                                      <td>@nusra</td>
                                    </tr>
                                    <tr>
                                      <td>5.00pm - 6:30pm</td>
                                      <td>Lounge Adda</td>
                                      <td>Rj Nusra</td>
                                      <td>@nusra</td>
                                    </tr>
                                    <tr>
                                      <td>7.00pm - 10:00pm</td>
                                      <td>Lounge Adda</td>
                                      <td>Rj Nusra</td>
                                      <td>@nusra</td>
                                    </tr>
                                    <tr>
                                      <td>10.00pm - 11:30pm</td>
                                      <td>Lounge Adda</td>
                                      <td>Rj Nusra</td>
                                      <td>@nusra</td>
                                    </tr>
                                    <tr>
                                      <td>11.30pm - 02:00am</td>
                                      <td>Lounge Adda</td>
                                      <td>Rj Nusra</td>
                                      <td>@nusra</td>
                                    </tr>
                                  </tbody>
                                </table>
                              </div>
                            <div class="tab-pane fade table-responsive table-responsive-sm table-responsive-xs" id="v-pills-tuesday" role="tabpanel" aria-labelledby="v-pills-tuesday-tab">
                                <table class="table table-borderless">
                                  <thead>
                                    <tr>
                                        <th scope="col">Horario</th>
                                        <th scope="col">Espacio Radial</th>
                                        <th scope="col">Conductor</th>
                                        <th scope="col">Twitter</th>
                                      </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td>06.00am - 8:00am</td>
                                      <td>Good Morning Network</td>
                                      <td>Rj Rockey</td>
                                      <td>@rrockey</td>
                                    </tr>
                                    <tr>
                                      <td>08.00am - 10:30am</td>
                                      <td>Musty with ron</td>
                                      <td>Rj Ronne</td>
                                      <td>@ronne</td>
                                    </tr>
                                    <tr>
                                      <td>10.00am - 1:00pm</td>
                                      <td>Gaan Bazz</td>
                                      <td>Rj Pinkey</td>
                                      <td>@pinkey</td>
                                    </tr>
                                    <tr>
                                      <td>1.30pm - 3:30pm</td>
                                      <td>Lounge Adda</td>
                                      <td>Rj Nusra</td>
                                      <td>@nusra</td>
                                    </tr>
                                  </tbody>
                                </table>
                            </div>
                            <div class="tab-pane fade" id="v-pills-wednesday" role="tabpanel" aria-labelledby="v-pills-wednesday-tab">
                                <table class="table table-borderless">
                                  <thead>
                                    
                                        <tr>
                                            <th scope="col">Horario</th>
                                            <th scope="col">Espacio Radial</th>
                                            <th scope="col">Conductor</th>
                                            <th scope="col">Twitter</th>
                                          </tr>
                                   
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td>06.00am - 8:00am</td>
                                      <td>Good Morning Network</td>
                                      <td>Rj Rockey</td>
                                      <td>@rrockey</td>
                                    </tr>
                                    <tr>
                                      <td>08.00am - 10:30am</td>
                                      <td>Musty with ron</td>
                                      <td>Rj Ronne</td>
                                      <td>@ronne</td>
                                    </tr>
                                    
                                    <tr>
                                      <td>5.00pm - 6:30pm</td>
                                      <td>Lounge Adda</td>
                                      <td>Rj Nusra</td>
                                      <td>@nusra</td>
                                    </tr>
                                    <tr>
                                      <td>7.00pm - 10:00pm</td>
                                      <td>Lounge Adda</td>
                                      <td>Rj Nusra</td>
                                      <td>@nusra</td>
                                    </tr>
                                    <tr>
                                      <td>10.00pm - 11:30pm</td>
                                      <td>Lounge Adda</td>
                                      <td>Rj Nusra</td>
                                      <td>@nusra</td>
                                    </tr>
                                    <tr>
                                      <td>11.30pm - 02:00am</td>
                                      <td>Lounge Adda</td>
                                      <td>Rj Nusra</td>
                                      <td>@nusra</td>
                                    </tr>
                                  </tbody>
                                </table>
                            </div>
                            <div class="tab-pane fade table-responsive table-responsive-sm table-responsive-xs" id="v-pills-thursday" role="tabpanel" aria-labelledby="v-pills-thursday-tab">
                                <table class="table table-borderless">
                                  <thead>
                                    <tr>
                                        <th scope="col">Horario</th>
                                        <th scope="col">Espacio Radial</th>
                                        <th scope="col">Conductor</th>
                                        <th scope="col">Twitter</th>
                                      </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td>06.00am - 8:00am</td>
                                      <td>Good Morning Network</td>
                                      <td>Rj Rockey</td>
                                      <td>@rrockey</td>
                                    </tr>
                                    <tr>
                                      <td>08.00am - 10:30am</td>
                                      <td>Musty with ron</td>
                                      <td>Rj Ronne</td>
                                      <td>@ronne</td>
                                    </tr>
                                    <tr>
                                      <td>10.00am - 1:00pm</td>
                                      <td>Gaan Bazz</td>
                                      <td>Rj Pinkey</td>
                                      <td>@pinkey</td>
                                    </tr>
                                    <tr>
                                      <td>1.30pm - 3:30pm</td>
                                      <td>Lounge Adda</td>
                                      <td>Rj Nusra</td>
                                      <td>@nusra</td>
                                    </tr>
                                    <tr>
                                      <td>3.30pm - 5:00pm</td>
                                      <td>Lounge Adda</td>
                                      <td>Rj Nusra</td>
                                      <td>@nusra</td>
                                    </tr>
                                    <tr>
                                      <td>5.00pm - 6:30pm</td>
                                      <td>Lounge Adda</td>
                                      <td>Rj Nusra</td>
                                      <td>@nusra</td>
                                    </tr>
                                    <tr>
                                      <td>7.00pm - 10:00pm</td>
                                      <td>Lounge Adda</td>
                                      <td>Rj Nusra</td>
                                      <td>@nusra</td>
                                    </tr>
                                    <tr>
                                      <td>10.00pm - 11:30pm</td>
                                      <td>Lounge Adda</td>
                                      <td>Rj Nusra</td>
                                      <td>@nusra</td>
                                    </tr>
                                    <tr>
                                      <td>11.30pm - 02:00am</td>
                                      <td>Lounge Adda</td>
                                      <td>Rj Nusra</td>
                                      <td>@nusra</td>
                                    </tr>
                                  </tbody>
                                </table>
                            </div>
                            <div class="tab-pane fade table-responsive table-responsive-sm table-responsive-xs" id="v-pills-friday" role="tabpanel" aria-labelledby="v-pills-friday-tab">
                                <table class="table table-borderless">
                                  <thead>
                                    <tr>
                                        <th scope="col">Horario</th>
                                        <th scope="col">Espacio Radial</th>
                                        <th scope="col">Conductor</th>
                                        <th scope="col">Twitter</th>
                                      </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td>06.00am - 8:00am</td>
                                      <td>Good Morning Network</td>
                                      <td>Rj Rockey</td>
                                      <td>@rrockey</td>
                                    </tr>
                                    <tr>
                                      <td>08.00am - 10:30am</td>
                                      <td>Musty with ron</td>
                                      <td>Rj Ronne</td>
                                      <td>@ronne</td>
                                    </tr>
                                    <tr>
                                      <td>10.00am - 1:00pm</td>
                                      <td>Gaan Bazz</td>
                                      <td>Rj Pinkey</td>
                                      <td>@pinkey</td>
                                    </tr>
                                    <tr>
                                      <td>1.30pm - 3:30pm</td>
                                      <td>Lounge Adda</td>
                                      <td>Rj Nusra</td>
                                      <td>@nusra</td>
                                    </tr>
                                    <tr>
                                      <td>7.00pm - 10:00pm</td>
                                      <td>Lounge Adda</td>
                                      <td>Rj Nusra</td>
                                      <td>@nusra</td>
                                    </tr>
                                    <tr>
                                      <td>10.00pm - 11:30pm</td>
                                      <td>Lounge Adda</td>
                                      <td>Rj Nusra</td>
                                      <td>@nusra</td>
                                    </tr>
                                    <tr>
                                      <td>11.30pm - 02:00am</td>
                                      <td>Lounge Adda</td>
                                      <td>Rj Nusra</td>
                                      <td>@nusra</td>
                                    </tr>
                                  </tbody>
                                </table>
                            </div>
                            <div class="tab-pane fade table-responsive table-responsive-sm table-responsive-xs" id="v-pills-saturday" role="tabpanel" aria-labelledby="v-pills-saturday-tab">
                                <table class="table table-borderless">
                                  <thead>
                                    <tr>
                                        <th scope="col">Horario</th>
                                        <th scope="col">Espacio Radial</th>
                                        <th scope="col">Conductor</th>
                                        <th scope="col">Twitter</th>
                                      </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td>06.00am - 8:00am</td>
                                      <td>Good Morning Network</td>
                                      <td>Rj Rockey</td>
                                      <td>@rrockey</td>
                                    </tr>
                                    <tr>
                                      <td>08.00am - 10:30am</td>
                                      <td>Musty with ron</td>
                                      <td>Rj Ronne</td>
                                      <td>@ronne</td>
                                    </tr>
                                    <tr>
                                      <td>10.00am - 1:00pm</td>
                                      <td>Gaan Bazz</td>
                                      <td>Rj Pinkey</td>
                                      <td>@pinkey</td>
                                    </tr>
                                    <tr>
                                      <td>1.30pm - 3:30pm</td>
                                      <td>Lounge Adda</td>
                                      <td>Rj Nusra</td>
                                      <td>@nusra</td>
                                    </tr>
                                    <tr>
                                      <td>3.30pm - 5:00pm</td>
                                      <td>Lounge Adda</td>
                                      <td>Rj Nusra</td>
                                      <td>@nusra</td>
                                    </tr>
                                    <tr>
                                      <td>5.00pm - 6:30pm</td>
                                      <td>Lounge Adda</td>
                                      <td>Rj Nusra</td>
                                      <td>@nusra</td>
                                    </tr>
                                  </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section><!--/Daily Program Schedule-->

        <!--Photo Gallery Area-->
        <section class="portfolio-area section-padding">
        
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-7 col-md-12 col-sm-12 col-xs-12 centered wow fadeInUp" data-wow-delay="0.3s">
                        <div class="section-title cl-black">
                            <h2>Nuestros Eventos</h2>
                            <p>Ven y ve nuestra galería de fotos sobre nuestros eventos, show en vivo y en estaciones de radio.</p>
                        </div>
                    </div>
                </div>

                <div class="text-center mb-40 wow fadeInUp" data-wow-delay="0.4s">
                    <ul class="portfolio-filter">
                        <li class="active"><a href="#" data-filter="*"> Todos</a></li>
                        <li><a href="#" data-filter=".cat1">Estudio <span>05</span></a></li>
                        <li><a href="#" data-filter=".cat2">Show En vivo <span>03</span></a></li>
                        <li><a href="#" data-filter=".cat3">Populares <span>04</span></a></li>
                        <li><a href="#" data-filter=".cat4">Estación de Radio <span>03</span></a></li>
                    </ul>
                </div>

                <div class="row portfolio portfolio-gallery column-3 gutter wow fadeInUp" data-wow-delay="0.5s">

                    <div class="portfolio-item cat1 cat3 ">
                        <a href="assets/images/portfolios/1.jpg" class="thumb popup-gallery" title="">
                            <img src="assets/images/portfolios/1.jpg" alt="">
                            <div class="portfolio-hover">
                                <div class="portfolio-description">
                                    <img src="assets/images/search.png" alt="">
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="portfolio-item cat2 cat4 ">
                        <a href="assets/images/portfolios/2.jpg" class="thumb popup-gallery" title="">
                            <img src="assets/images/portfolios/2.jpg" alt="">
                            <div class="portfolio-hover">
                                <div class="portfolio-description">
                                    <img src="assets/images/search.png" alt="">
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="portfolio-item cat1 cat5 ">
                        <a href="https://www.youtube.com/watch?v=GT6-H4BRyqQ" class="thumb video-popup" title="">
                            <img src="assets/images/portfolios/3.jpg" alt="">
                            <div class="portfolio-hover">
                                <div class="portfolio-description">
                                    <img src="assets/images/video.png" alt="">
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="portfolio-item cat3 ">
                        <a href="https://www.youtube.com/watch?v=GT6-H4BRyqQ" class="thumb video-popup" title="">
                            <img src="assets/images/portfolios/4.jpg" alt="">
                            <div class="portfolio-hover">
                                <div class="portfolio-description">
                                    <img src="assets/images/video.png" alt="">
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="portfolio-item cat1 cat2 ">
                        <a href="assets/images/portfolios/5.jpg" class="thumb popup-gallery" title="">
                            <img src="assets/images/portfolios/5.jpg" alt="">
                            <div class="portfolio-hover">
                                <div class="portfolio-description">
                                    <img src="assets/images/search.png" alt="">
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="portfolio-item cat3 cat4 ">
                        <a href="assets/images/portfolios/6.jpg" class="thumb popup-gallery" title="">
                            <img src="assets/images/portfolios/6.jpg" alt="">
                            <div class="portfolio-hover">
                                <div class="portfolio-description">
                                    <img src="assets/images/search.png" alt="">
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="portfolio-item cat1 cat5 ">
                        <a href="assets/images/portfolios/7.jpg" class="thumb popup-gallery" title="">
                            <img src="assets/images/portfolios/7.jpg" alt="">
                            <div class="portfolio-hover">
                                <div class="portfolio-description">
                                    <img src="assets/images/search.png" alt="">
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="portfolio-item cat2 cat3 ">
                        <a href="assets/images/portfolios/8.jpg" class="thumb popup-gallery" title="">
                            <img src="assets/images/portfolios/8.jpg" alt="">
                            <div class="portfolio-hover">
                                <div class="portfolio-description">
                                    <img src="assets/images/search.png" alt="">
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="portfolio-item cat1 cat4 ">
                        <a href="https://www.youtube.com/watch?v=GT6-H4BRyqQ" class="thumb video-popup" title="">
                            <img src="assets/images/portfolios/9.jpg" alt="">
                            <div class="portfolio-hover">
                                <div class="portfolio-description">
                                    <img src="assets/images/video.png" alt="">
                                </div>
                            </div>
                        </a>
                    </div>

                </div>
            </div>
        </section><!--/Photo Gallery Area-->

        <!--Offer Area-->
        <section class="offer-area section-padding">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12 wow fadeInLeft" data-wow-delay="0.3s">
                        <div class="row">
                            <div class="col-lg-10 col-md-12 col-sm-12 col-xs-12">
                                <div class="offer-area-content">
                                    <div class="section-title-left cl-white">
                                        <h2>Quieres aparecer en la Radio</h2>
                                        <p> La publicidad en GMO es integra y de calidad. Tu marca estará en un lugar profesional y con una buena imagen, que esperas.</p>
                                    </div>
                                    <h4 class="cl-black">Baladas increíbles que harán que tus amigos recuerden la epoca dorada de la musica romantica. </h4>
                                    <p class="cl-black">Repulsive questions contented him few extensive supported. Of remark thoroughly he appearance in. Supposing tolerably applauded or of be. Suffering unfeeling so objection agreeable allowance me of. Ask within entire season far who family. As be valley warmth assure on. Park girl they rich hour new well way you.</p>
                                    <a href="#" class="bttn-mid btn-fill">Contactanos</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12 wow fadeInRight" data-wow-delay="0.3s">
                        <div class="offer-form">
                            <h3>Envianos tu petición</h3>
                            <form action="#">
                                <input type="text" placeholder="Nombre">
                                <input type="email" placeholder="Correo Electronico ">
                                <input type="text" placeholder="Teléfono">
                                <input type="text" placeholder="Dirección">
                                <textarea name="message" rows="3" placeholder="Escribe tu Mensaje"></textarea>
                                <button type="submit" class="bttn-mid btn-fill">Envíar Ahora</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section><!--/Offer Area-->

        <!--Become Sponsor-->
        <section class="become-sponsor section-padding gray-bg" id="sponsor">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-7 col-md-12 col-sm-12 col-xs-12 centered wow fadeInUp" data-wow-delay="0.3s">
                        <div class="section-title cl-black">
                            <h2>Conviértete en un patrocinador</h2>
                            <p>Needed feebly dining oh talked wisdom oppose at. Applauded use attempted strangers now are middleton. contented him few extensive supported</p>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12 centered wow fadeInUp" data-wow-delay="0.3s">
                        <form action="#" class="sponsor-form">
                            <div class="row">
                                <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                                    <input type="text" placeholder="Nombre*">
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                                    <input type="text" placeholder="Apellido*">
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                                    <input type="email" placeholder="Correo electrónico*">
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                                    <input type="text" placeholder="Número de Teléfono">
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                                    <input type="text" placeholder="Nombre de la Empresa">
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                                    <select name="state">
                                    <option value="AF">Afganistán</option>
                                    <option value="AL">Albania</option>
                                    <option value="DE">Alemania</option>
                                    <option value="AD">Andorra</option>
                                    <option value="AO">Angola</option>
                                    <option value="AI">Anguilla</option>
                                    <option value="AQ">Antártida</option>
                                    <option value="AG">Antigua y Barbuda</option>
                                    <option value="AN">Antillas Holandesas</option>
                                    <option value="SA">Arabia Saudí</option>
                                    <option value="DZ">Argelia</option>
                                    <option value="AR">Argentina</option>
                                    <option value="AM">Armenia</option>
                                    <option value="AW">Aruba</option>
                                    <option value="AU">Australia</option>
                                    <option value="AT">Austria</option>
                                    <option value="AZ">Azerbaiyán</option>
                                    <option value="BS">Bahamas</option>
                                    <option value="BH">Bahrein</option>
                                    <option value="BD">Bangladesh</option>
                                    <option value="BB">Barbados</option>
                                    <option value="BE">Bélgica</option>
                                    <option value="BZ">Belice</option>
                                    <option value="BJ">Benin</option>
                                    <option value="BM">Bermudas</option>
                                    <option value="BY">Bielorrusia</option>
                                    <option value="MM">Birmania</option>
                                    <option value="BO">Bolivia</option>
                                    <option value="BA">Bosnia y Herzegovina</option>
                                    <option value="BW">Botswana</option>
                                    <option value="BR">Brasil</option>
                                    <option value="BN">Brunei</option>
                                    <option value="BG">Bulgaria</option>
                                    <option value="BF">Burkina Faso</option>
                                    <option value="BI">Burundi</option>
                                    <option value="BT">Bután</option>
                                    <option value="CV">Cabo Verde</option>
                                    <option value="KH">Camboya</option>
                                    <option value="CM">Camerún</option>
                                    <option value="CA">Canadá</option>
                                    <option value="TD">Chad</option>
                                    <option value="CL">Chile</option>
                                    <option value="CN">China</option>
                                    <option value="CY">Chipre</option>
                                    <option value="VA">Ciudad del Vaticano (Santa Sede)</option>
                                    <option value="CO">Colombia</option>
                                    <option value="KM">Comores</option>
                                    <option value="CG">Congo</option>
                                    <option value="CD">Congo, República Democrática del</option>
                                    <option value="KR">Corea</option>
                                    <option value="KP">Corea del Norte</option>
                                    <option value="CI">Costa de Marfíl</option>
                                    <option value="CR">Costa Rica</option>
                                    <option value="HR">Croacia (Hrvatska)</option>
                                    <option value="CU">Cuba</option>
                                    <option value="DK">Dinamarca</option>
                                    <option value="DJ">Djibouti</option>
                                    <option value="DM">Dominica</option>
                                    <option value="EC">Ecuador</option>
                                    <option value="EG">Egipto</option>
                                    <option value="SV">El Salvador</option>
                                    <option value="AE">Emiratos Árabes Unidos</option>
                                    <option value="ER">Eritrea</option>
                                    <option value="SI">Eslovenia</option>
                                    <option value="ES">España</option>
                                    <option value="US">Estados Unidos</option>
                                    <option value="EE">Estonia</option>
                                    <option value="ET">Etiopía</option>
                                    <option value="FJ">Fiji</option>
                                    <option value="PH">Filipinas</option>
                                    <option value="FI">Finlandia</option>
                                    <option value="FR">Francia</option>
                                    <option value="GA">Gabón</option>
                                    <option value="GM">Gambia</option>
                                    <option value="GE">Georgia</option>
                                    <option value="GH">Ghana</option>
                                    <option value="GI">Gibraltar</option>
                                    <option value="GD">Granada</option>
                                    <option value="GR">Grecia</option>
                                    <option value="GL">Groenlandia</option>
                                    <option value="GP">Guadalupe</option>
                                    <option value="GU">Guam</option>
                                    <option value="GT">Guatemala</option>
                                    <option value="GY">Guayana</option>
                                    <option value="GF">Guayana Francesa</option>
                                    <option value="GN">Guinea</option>
                                    <option value="GQ">Guinea Ecuatorial</option>
                                    <option value="GW">Guinea-Bissau</option>
                                    <option value="HT">Haití</option>
                                    <option value="HN">Honduras</option>
                                    <option value="HU">Hungría</option>
                                    <option value="IN">India</option>
                                    <option value="ID">Indonesia</option>
                                    <option value="IQ">Irak</option>
                                    <option value="IR">Irán</option>
                                    <option value="IE">Irlanda</option>
                                    <option value="BV">Isla Bouvet</option>
                                    <option value="CX">Isla de Christmas</option>
                                    <option value="IS">Islandia</option>
                                    <option value="KY">Islas Caimán</option>
                                    <option value="CK">Islas Cook</option>
                                    <option value="CC">Islas de Cocos o Keeling</option>
                                    <option value="FO">Islas Faroe</option>
                                    <option value="HM">Islas Heard y McDonald</option>
                                    <option value="FK">Islas Malvinas</option>
                                    <option value="MP">Islas Marianas del Norte</option>
                                    <option value="MH">Islas Marshall</option>
                                    <option value="UM">Islas menores de Estados Unidos</option>
                                    <option value="PW">Islas Palau</option>
                                    <option value="SB">Islas Salomón</option>
                                    <option value="SJ">Islas Svalbard y Jan Mayen</option>
                                    <option value="TK">Islas Tokelau</option>
                                    <option value="TC">Islas Turks y Caicos</option>
                                    <option value="VI">Islas Vírgenes (EEUU)</option>
                                    <option value="VG">Islas Vírgenes (Reino Unido)</option>
                                    <option value="WF">Islas Wallis y Futuna</option>
                                    <option value="IL">Israel</option>
                                    <option value="IT">Italia</option>
                                    <option value="JM">Jamaica</option>
                                    <option value="JP">Japón</option>
                                    <option value="JO">Jordania</option>
                                    <option value="KZ">Kazajistán</option>
                                    <option value="KE">Kenia</option>
                                    <option value="KG">Kirguizistán</option>
                                    <option value="KI">Kiribati</option>
                                    <option value="KW">Kuwait</option>
                                    <option value="LA">Laos</option>
                                    <option value="LS">Lesotho</option>
                                    <option value="LV">Letonia</option>
                                    <option value="LB">Líbano</option>
                                    <option value="LR">Liberia</option>
                                    <option value="LY">Libia</option>
                                    <option value="LI">Liechtenstein</option>
                                    <option value="LT">Lituania</option>
                                    <option value="LU">Luxemburgo</option>
                                    <option value="MK">Macedonia, Ex-República Yugoslava de</option>
                                    <option value="MG">Madagascar</option>
                                    <option value="MY">Malasia</option>
                                    <option value="MW">Malawi</option>
                                    <option value="MV">Maldivas</option>
                                    <option value="ML">Malí</option>
                                    <option value="MT">Malta</option>
                                    <option value="MA">Marruecos</option>
                                    <option value="MQ">Martinica</option>
                                    <option value="MU">Mauricio</option>
                                    <option value="MR">Mauritania</option>
                                    <option value="YT">Mayotte</option>
                                    <option value="MX"selected >México</option>
                                    <option value="FM">Micronesia</option>
                                    <option value="MD">Moldavia</option>
                                    <option value="MC">Mónaco</option>
                                    <option value="MN">Mongolia</option>
                                    <option value="MS">Montserrat</option>
                                    <option value="MZ">Mozambique</option>
                                    <option value="NA">Namibia</option>
                                    <option value="NR">Nauru</option>
                                    <option value="NP">Nepal</option>
                                    <option value="NI">Nicaragua</option>
                                    <option value="NE">Níger</option>
                                    <option value="NG">Nigeria</option>
                                    <option value="NU">Niue</option>
                                    <option value="NF">Norfolk</option>
                                    <option value="NO">Noruega</option>
                                    <option value="NC">Nueva Caledonia</option>
                                    <option value="NZ">Nueva Zelanda</option>
                                    <option value="OM">Omán</option>
                                    <option value="NL">Países Bajos</option>
                                    <option value="PA">Panamá</option>
                                    <option value="PG">Papúa Nueva Guinea</option>
                                    <option value="PK">Paquistán</option>
                                    <option value="PY">Paraguay</option>
                                    <option value="PE">Perú</option>
                                    <option value="PN">Pitcairn</option>
                                    <option value="PF">Polinesia Francesa</option>
                                    <option value="PL">Polonia</option>
                                    <option value="PT">Portugal</option>
                                    <option value="PR">Puerto Rico</option>
                                    <option value="QA">Qatar</option>
                                    <option value="UK">Reino Unido</option>
                                    <option value="CF">República Centroafricana</option>
                                    <option value="CZ">República Checa</option>
                                    <option value="ZA">República de Sudáfrica</option>
                                    <option value="DO">República Dominicana</option>
                                    <option value="SK">República Eslovaca</option>
                                    <option value="RE">Reunión</option>
                                    <option value="RW">Ruanda</option>
                                    <option value="RO">Rumania</option>
                                    <option value="RU">Rusia</option>
                                    <option value="EH">Sahara Occidental</option>
                                    <option value="KN">Saint Kitts y Nevis</option>
                                    <option value="WS">Samoa</option>
                                    <option value="AS">Samoa Americana</option>
                                    <option value="SM">San Marino</option>
                                    <option value="VC">San Vicente y Granadinas</option>
                                    <option value="SH">Santa Helena</option>
                                    <option value="LC">Santa Lucía</option>
                                    <option value="ST">Santo Tomé y Príncipe</option>
                                    <option value="SN">Senegal</option>
                                    <option value="SC">Seychelles</option>
                                    <option value="SL">Sierra Leona</option>
                                    <option value="SG">Singapur</option>
                                    <option value="SY">Siria</option>
                                    <option value="SO">Somalia</option>
                                    <option value="LK">Sri Lanka</option>
                                    <option value="PM">St Pierre y Miquelon</option>
                                    <option value="SZ">Suazilandia</option>
                                    <option value="SD">Sudán</option>
                                    <option value="SE">Suecia</option>
                                    <option value="CH">Suiza</option>
                                    <option value="SR">Surinam</option>
                                    <option value="TH">Tailandia</option>
                                    <option value="TW">Taiwán</option>
                                    <option value="TZ">Tanzania</option>
                                    <option value="TJ">Tayikistán</option>
                                    <option value="TF">Territorios franceses del Sur</option>
                                    <option value="TP">Timor Oriental</option>
                                    <option value="TG">Togo</option>
                                    <option value="TO">Tonga</option>
                                    <option value="TT">Trinidad y Tobago</option>
                                    <option value="TN">Túnez</option>
                                    <option value="TM">Turkmenistán</option>
                                    <option value="TR">Turquía</option>
                                    <option value="TV">Tuvalu</option>
                                    <option value="UA">Ucrania</option>
                                    <option value="UG">Uganda</option>
                                    <option value="UY">Uruguay</option>
                                    <option value="UZ">Uzbekistán</option>
                                    <option value="VU">Vanuatu</option>
                                    <option value="VE">Venezuela</option>
                                    <option value="VN">Vietnam</option>
                                    <option value="YE">Yemen</option>
                                    <option value="YU">Yugoslavia</option>
                                    <option value="ZM">Zambia</option>
                                    <option value="ZW">Zimbabue</option>
                                    </select>
                                </div>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <textarea name="textMessage" rows="4" placeholder="Escribe tu Mensaje"></textarea>
                                </div>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <button type="submit" class="bttn-mid btn-fill">Envíar Mensaje</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section><!--/Become Sponsor-->

        <!--Partner Logos-->
        <section class="partner-logo-area section-padding-2">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-7 col-md-12 col-sm-12 col-xs-12 centered wow fadeInUp" data-wow-delay="0.3s">
                        <div class="section-title cl-black">
                            <h2>Nuestros colaboradores en GMO</h2>
                            <p> Siempre de la mano con el proceso de desarrollo, mejora y logistica.</p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 wow fadeInLeft" data-wow-delay="0.4s">
                        <div class="single-partners owl-carousel">
                            <a href="#"><img src="assets/images/partner-1.jpg" alt=""></a>
                             <a href="#"><img src="assets/images/partner-2.jpg" alt=""></a>
                             <a href="#"><img src="assets/images/partner-3.jpg" alt=""></a>
                             <a href="#"><img src="assets/images/partner-1.jpg" alt=""></a>
                             <a href="#"><img src="assets/images/partner-2.jpg" alt=""></a>
                        </div>
                    </div>
                </div>
            </div>
        </section><!--/Partner Logos-->

        <!--Latest News-->
        <section class="latest-news section-padding-2 gray-bg">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-7 col-md-12 col-sm-12 col-xs-12 centered wow fadeInUp" data-wow-delay="0.3s">
                        <div class="section-title cl-black">
                            <h2>Publicaciones Recientes</h2>
                            <p>Descubre la ultima tendencia en radios, eventos musicales, show en vivo, biografias de artistas y mucho más en Nuestro
                            espacio en la web.</p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <?php foreach ($posts as $post):?>
                    
                        <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12 wow fadeInUp" data-wow-delay="0.4s">
                            <div class="single-blog">
                                <img src="<?=base_url('uploads/').$post->portada?>" alt="">
                                <div class="blog-meta-content">
                                    <div class="blog-meta">
                                        <a href="#"><i class="fa fa-user"></i><?=$this->usuario->getAuthorNameById($post->redactor);?></a>                                        
                                    </div>
                                    <h2><a href="<?=base_url('blog-details/').$post->id;?>"><?=$post->titulo?></a></h2>
                                </div>
                            </div>
                        </div>
                    <?php endforeach;?>                    
                </div>
            </div>
        </section><!--/Latest News-->