
        <!--Footer Area-->
        <footer class="footer-area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
                        <div class="footer-menu">
                            <ul>
                                <li><a href="#">Inicio</a></li>
                                <li><a href="#">Acerca de</a></li>
                                <li><a href="#">Radio Chat</a></li>
                                <li><a href="#">Blog</a></li>
                               
                                <li><a href="#">Contactanos</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 col-sm-12">
                        <div class="footer-social">
                            <a href="#"><i class="fa fa-facebook"></i></a>
                            <a href="#"><i class="fa fa-twitter"></i></a>
                            <a href="#"><i class="fa fa-linkedin"></i></a>
                           
                            <a href="#"><i class="fa fa-instagram"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </footer><!--/Footer Area-->

			
		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="<?=base_url('assets/js/jquery-3.2.1.min.js')?>"></script>
        <script src="<?=base_url('assets/js/jquery-migrate.js')?>"></script>

        <script src="<?=base_url('assets/js/popper.js')?>"></script>
        <script src="<?=base_url('assets/js/bootstrap.min.js')?>"></script>
		<script src="<?=base_url('assets/js/owl.carousel.min.js')?>"></script>
        <script src="<?=base_url('assets/js/scrollUp.min.js')?>"></script>

        <script src="<?=base_url('assets/js/magnific-popup.min.js')?>"></script>
		<script src="<?=base_url('assets/js/imagesloaded.pkgd.min.js')?>"></script>
        <script src="<?=base_url('assets/js/isotope.pkgd.min.js')?>"></script>

        <script src="<?=base_url('assets/js/wow.min.js')?>"></script>
        <script src="<?=base_url('assets/js/script.js')?>"></script>
        
    </body>
</html>