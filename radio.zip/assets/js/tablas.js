
    $(document).ready( function () {
        $('#tabla').DataTable();
    } );
